from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import Command, PathJoinSubstitution


def generate_launch_description():
    # Use the URDF + RViz config from my_robot_description
    description_pkg = FindPackageShare('my_robot_description')
    urdf_file = PathJoinSubstitution(
        [description_pkg, 'urdf', 'my_robot.urdf.xacro']
    )
    rviz_config = PathJoinSubstitution(
        [description_pkg, 'rviz', 'gesture_robot.rviz']
    )

    robot_description = Command(['xacro ', urdf_file])

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[{'robot_description': robot_description}],
    )

    joint_state_publisher_gui = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
    )

    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config],
        output='screen',
    )

    fake_imu = Node(
        package='my_robot_sim',
        executable='fake_imu',
        name='fake_imu',
    )

    fake_ultrasonic = Node(
        package='my_robot_sim',
        executable='fake_ultrasonic',
        name='fake_ultrasonic',
    )

    gesture_marker = Node(
        package='my_robot_sim',
        executable='gesture_marker',
        name='gesture_marker',
    )

    fake_camera = Node(
        package='my_robot_sim',
        executable='fake_camera',
        name='fake_camera',
    )

    return LaunchDescription([
        robot_state_publisher,
        joint_state_publisher_gui,
        rviz,
        fake_imu,
        fake_ultrasonic,
        gesture_marker,
        fake_camera,
    ])
