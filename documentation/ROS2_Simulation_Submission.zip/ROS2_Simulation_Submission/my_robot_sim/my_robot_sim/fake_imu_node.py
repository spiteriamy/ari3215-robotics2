import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from std_msgs.msg import Header


class FakeImuNode(Node):
    def __init__(self):
        super().__init__('fake_imu')
        self.publisher_ = self.create_publisher(Imu, 'imu', 10)
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz
        self.yaw = 0.0

    def timer_callback(self):
        msg = Imu()
        msg.header = Header()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'imu_link'  # matches URDF link

        # slowly rotate around Z (like turning on the spot)
        self.yaw += 0.02
        half_yaw = self.yaw * 0.5
        msg.orientation.z = math.sin(half_yaw)
        msg.orientation.w = math.cos(half_yaw)

        # leave other fields zero for now
        self.publisher_.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = FakeImuNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
