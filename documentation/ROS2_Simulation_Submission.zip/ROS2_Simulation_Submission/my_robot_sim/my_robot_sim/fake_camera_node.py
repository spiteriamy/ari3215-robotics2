import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Header


class FakeCameraNode(Node):
    def __init__(self):
        super().__init__('fake_camera')
        self.publisher_ = self.create_publisher(Image, 'camera/image_raw', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)  # 10 Hz
        self.t = 0

        self.width = 320
        self.height = 240

    def timer_callback(self):
        self.t += 1

        img = Image()
        img.header = Header()
        img.header.stamp = self.get_clock().now().to_msg()
        img.header.frame_id = 'camera_link'  # matches URDF link

        img.height = self.height
        img.width = self.width
        img.encoding = 'rgb8'
        img.is_bigendian = 0
        img.step = self.width * 3

        # Simple animated pattern so you can SEE it changing
        data = bytearray(self.height * self.width * 3)
        for y in range(self.height):
            for x in range(self.width):
                i = (y * self.width + x) * 3
                r = (x + self.t) % 256
                g = (y * 2) % 256
                b = (self.t * 4) % 256
                data[i] = r
                data[i + 1] = g
                data[i + 2] = b

        img.data = bytes(data)

        self.publisher_.publish(img)


def main(args=None):
    rclpy.init(args=args)
    node = FakeCameraNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
