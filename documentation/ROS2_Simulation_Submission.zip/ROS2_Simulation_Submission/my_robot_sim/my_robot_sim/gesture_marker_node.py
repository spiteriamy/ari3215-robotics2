import rclpy
from rclpy.node import Node
from visualization_msgs.msg import Marker
from std_msgs.msg import Header, ColorRGBA


class GestureMarkerNode(Node):
    def __init__(self):
        super().__init__('gesture_marker')
        self.publisher_ = self.create_publisher(Marker, 'gesture_marker', 10)
        self.timer = self.create_timer(0.5, self.timer_callback)

        self.commands = [
            "GESTURE: FORWARD",
            "GESTURE: LEFT TURN",
            "GESTURE: RIGHT TURN",
            "GESTURE: STOP",
        ]
        self.index = 0

    def timer_callback(self):
        text = self.commands[self.index]
        self.index = (self.index + 1) % len(self.commands)

        m = Marker()
        m.header = Header()
        m.header.stamp = self.get_clock().now().to_msg()
        m.header.frame_id = 'base_link'  # float above robot

        m.ns = 'gesture_text'
        m.id = 0
        m.type = Marker.TEXT_VIEW_FACING
        m.action = Marker.ADD

        m.pose.position.x = 0.0
        m.pose.position.y = 0.0
        m.pose.position.z = 0.5  # half meter above robot

        m.scale.z = 0.15  # text height

        m.color = ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)
        m.text = text

        self.publisher_.publish(m)


def main(args=None):
    rclpy.init(args=args)
    node = GestureMarkerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
