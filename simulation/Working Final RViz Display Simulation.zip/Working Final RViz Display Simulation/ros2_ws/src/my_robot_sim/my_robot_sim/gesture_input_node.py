import sys, termios, tty, select
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Int32

class GestureInput(Node):
    def __init__(self):
        super().__init__('gesture_input')

        self.pub_dir = self.create_publisher(String, '/gesture/direction', 10)
        self.pub_val = self.create_publisher(Int32, '/gesture/value', 10)

        self.direction = "STOP"
        self.value = 0

        self.get_logger().info("Gesture controls:")
        self.get_logger().info("W=FORWARD S=BACK A=LEFT D=RIGHT | 0..5=fingers | X=STOP | O=SECRET SPIN")

        self.old = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())
        self.timer = self.create_timer(0.05, self.tick)

    def tick(self):
        if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
            c = sys.stdin.read(1).lower()

            if c == 'w': self.direction = "FORWARD"
            elif c == 's': self.direction = "BACKWARD"
            elif c == 'a': self.direction = "LEFT"
            elif c == 'd': self.direction = "RIGHT"
            elif c == 'x': self.direction = "STOP"
            elif c == 'o': self.direction = "SECRET"
            elif c in "012345": self.value = int(c)

            self.pub_dir.publish(String(data=self.direction))
            self.pub_val.publish(Int32(data=self.value))

    def destroy_node(self):
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old)
        super().destroy_node()

def main():
    rclpy.init()
    node = GestureInput()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
