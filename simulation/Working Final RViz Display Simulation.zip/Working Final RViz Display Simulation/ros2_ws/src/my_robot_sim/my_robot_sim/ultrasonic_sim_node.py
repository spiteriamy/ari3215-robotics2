import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range
import math

class UltrasonicSim(Node):
    def __init__(self):
        super().__init__('ultrasonic_sim')
        self.front_pub = self.create_publisher(Range, '/ultrasonic/front', 10)
        self.rear_pub  = self.create_publisher(Range, '/ultrasonic/rear', 10)
        self.t = 0.0
        self.create_timer(0.1, self.tick)

    def make_msg(self, frame_id, rng):
        msg = Range()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = frame_id
        msg.radiation_type = Range.ULTRASOUND
        msg.field_of_view = 0.5
        msg.min_range = 0.05
        msg.max_range = 2.0
        msg.range = float(max(msg.min_range, min(msg.max_range, rng)))
        return msg

    def tick(self):
        self.t += 0.08
        # smooth oscillating distance so you can SEE it change in RViz
        front = 0.6 + 0.4 * math.sin(self.t)
        rear  = 0.6 + 0.4 * math.cos(self.t)
        self.front_pub.publish(self.make_msg("front_ultrasonic_link", front))
        self.rear_pub.publish(self.make_msg("rear_ultrasonic_link", rear))

def main():
    rclpy.init()
    rclpy.spin(UltrasonicSim())
    rclpy.shutdown()
