import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu

class ImuSim(Node):
    def __init__(self):
        super().__init__('imu_sim')
        self.pub = self.create_publisher(Imu, '/imu', 10)
        self.yaw = 0.0
        self.create_timer(0.05, self.tick)

    def tick(self):
        self.yaw += 0.01
        msg = Imu()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "imu_link"
        half = self.yaw / 2.0
        msg.orientation.z = math.sin(half)
        msg.orientation.w = math.cos(half)
        self.pub.publish(msg)

def main():
    rclpy.init()
    rclpy.spin(ImuSim())
    rclpy.shutdown()
