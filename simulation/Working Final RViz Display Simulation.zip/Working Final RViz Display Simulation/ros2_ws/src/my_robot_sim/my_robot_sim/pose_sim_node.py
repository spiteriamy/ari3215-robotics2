import math
import rclpy
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
from std_msgs.msg import String, Int32
from sensor_msgs.msg import Range

class PoseSim(Node):
    def __init__(self):
        super().__init__('pose_sim')
        self.tf = TransformBroadcaster(self)

        self.direction = "STOP"
        self.fingers = 0
        self.create_subscription(String, '/gesture/direction', self.on_dir, 10)
        self.create_subscription(Int32, '/gesture/value', self.on_val, 10)

        # Subscribe to ultrasonics so we can stop near obstacles
        self.front_range = 2.0
        self.rear_range = 2.0
        self.create_subscription(Range, '/ultrasonic/front', self.on_front, 10)
        self.create_subscription(Range, '/ultrasonic/rear', self.on_rear, 10)

        self.x, self.y, self.yaw = 0.0, 0.0, 0.0
        self.mode = "IDLE"
        self.time_left = 0.0
        self.turn_left = 0.0

        self.timer = self.create_timer(0.05, self.tick)  # 20Hz
        self.get_logger().info("PoseSim: publishing TF odom -> base_link")

    def on_dir(self, msg): self.direction = msg.data
    def on_val(self, msg): self.fingers = max(0, min(5, int(msg.data)))
    def on_front(self, msg): self.front_range = msg.range
    def on_rear(self, msg): self.rear_range = msg.range

    def can_move_forward(self):
        return self.front_range > 0.25

    def can_move_backward(self):
        return self.rear_range > 0.25

    def start_cmd(self):
        d = self.direction
        if d == "STOP":
            self.mode = "IDLE"
            return

        if d in ("FORWARD", "BACKWARD"):
            seconds = float(self.fingers)
            self.mode = "MOVE"
            self.time_left = seconds

        if d in ("LEFT", "RIGHT"):
            deg = 30 * self.fingers  # 30 degrees per finger
            if deg <= 0:
                self.mode = "IDLE"
                return
            self.mode = "TURN"
            self.turn_left = math.radians(deg) if d == "LEFT" else -math.radians(deg)

        if d == "SECRET":
            self.mode = "SPIN"

    def tick(self):
        dt = 0.05

        # start only when idle
        if self.mode == "IDLE" and self.direction != "STOP":
            self.start_cmd()

        # stop overrides everything
        if self.direction == "STOP":
            self.mode = "IDLE"
            self.time_left = 0.0
            self.turn_left = 0.0

        if self.mode == "MOVE":
            speed = 0.18
            if self.direction == "FORWARD":
                if not self.can_move_forward():
                    self.mode = "IDLE"
                else:
                    self.x += math.cos(self.yaw) * speed * dt
                    self.y += math.sin(self.yaw) * speed * dt
                    self.time_left -= dt
            elif self.direction == "BACKWARD":
                if not self.can_move_backward():
                    self.mode = "IDLE"
                else:
                    self.x -= math.cos(self.yaw) * speed * dt
                    self.y -= math.sin(self.yaw) * speed * dt
                    self.time_left -= dt

            if self.time_left <= 0:
                self.mode = "IDLE"

        elif self.mode == "TURN":
            # BEFORE turning: check front sensor (like your real robot "servo check")
            if self.front_range < 0.25:
                self.mode = "IDLE"
            else:
                ang_speed = math.radians(90)
                step = math.copysign(min(abs(self.turn_left), ang_speed * dt), self.turn_left)
                self.yaw += step
                self.turn_left -= step
                if abs(self.turn_left) < 1e-4:
                    self.mode = "IDLE"

        elif self.mode == "SPIN":
            self.yaw += math.radians(150) * dt  # spin
            # only stop when user hits X (STOP)

        # publish TF
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y

        half = self.yaw / 2.0
        t.transform.rotation.z = math.sin(half)
        t.transform.rotation.w = math.cos(half)

        self.tf.sendTransform(t)

def main():
    rclpy.init()
    rclpy.spin(PoseSim())
    rclpy.shutdown()
