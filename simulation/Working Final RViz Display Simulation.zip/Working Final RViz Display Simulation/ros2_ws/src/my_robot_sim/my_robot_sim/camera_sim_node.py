import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image

class CameraSim(Node):
    def __init__(self):
        super().__init__('camera_sim')
        self.pub = self.create_publisher(Image, '/camera/image_raw', 10)
        self.w, self.h = 320, 240
        self.t = 0
        self.create_timer(0.1, self.tick)

    def tick(self):
        self.t += 1
        img = Image()
        img.header.stamp = self.get_clock().now().to_msg()
        img.header.frame_id = "camera_link"
        img.height = self.h
        img.width = self.w
        img.encoding = "rgb8"
        img.step = self.w * 3

        data = bytearray(self.h * self.w * 3)
        for y in range(self.h):
            for x in range(self.w):
                i = (y*self.w + x)*3
                data[i]   = (x + self.t) % 256
                data[i+1] = (y*2) % 256
                data[i+2] = (self.t*4) % 256

        img.data = bytes(data)
        self.pub.publish(img)

def main():
    rclpy.init()
    rclpy.spin(CameraSim())
    rclpy.shutdown()
