#!/usr/bin/env python3
import math
import time
import subprocess

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from visualization_msgs.msg import Marker
from std_msgs.msg import Bool

from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped


class EffectsDriver(Node):
    """
    RViz-only "simulation":
    - Subscribes to /cmd_vel
    - Integrates pose and publishes TF (base_footprint -> base_link)
    - Publishes LED Marker (green glow on movement, blue on idle, red on stop)
    - Publishes buzzer Bool + optional system sound when "too close"
    """

    def __init__(self):
        super().__init__('effects_driver')

        # motion state
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.last_time = self.get_clock().now()

        self.cmd_v = 0.0
        self.cmd_w = 0.0

        # fake obstacle distance (you can replace this with real ultrasonic topic later)
        self.fake_distance_m = 0.50  # start "safe"

        self.tf_broadcaster = TransformBroadcaster(self)

        self.create_subscription(Twist, '/cmd_vel', self.on_cmd_vel, 10)

        self.led_pub = self.create_publisher(Marker, '/led_marker', 10)
        self.buzzer_pub = self.create_publisher(Bool, '/buzzer', 10)

        # run at 30 Hz
        self.timer = self.create_timer(1.0 / 30.0, self.tick)

        self.get_logger().info("effects_driver running: listens /cmd_vel, publishes TF + /led_marker + /buzzer")

    def on_cmd_vel(self, msg: Twist):
        self.cmd_v = float(msg.linear.x)
        self.cmd_w = float(msg.angular.z)

    def tick(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now
        if dt <= 0.0:
            return

        # ---- Fake distance logic (demo) ----
        # If moving forward, pretend obstacle gets closer
        if self.cmd_v > 0.01:
            self.fake_distance_m = max(0.05, self.fake_distance_m - 0.01)
        elif self.cmd_v < -0.01:
            self.fake_distance_m = max(0.05, self.fake_distance_m - 0.005)
        else:
            # recover slowly when idle
            self.fake_distance_m = min(0.50, self.fake_distance_m + 0.01)

        too_close = self.fake_distance_m < 0.15

        # If too close, force stop
        v = 0.0 if too_close else self.cmd_v
        w = 0.0 if too_close else self.cmd_w

        # ---- Integrate motion (2D) ----
        self.yaw += w * dt
        self.x += v * math.cos(self.yaw) * dt
        self.y += v * math.sin(self.yaw) * dt

        # ---- Publish TF base_footprint -> base_link ----
        t = TransformStamped()
        t.header.stamp = now.to_msg()
        t.header.frame_id = 'base_footprint'
        t.child_frame_id = 'base_link'
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0

        # quaternion from yaw
        qz = math.sin(self.yaw * 0.5)
        qw = math.cos(self.yaw * 0.5)
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = qz
        t.transform.rotation.w = qw

        self.tf_broadcaster.sendTransform(t)

        # ---- LED Marker (glow strip overlay) ----
        # Color rules:
        # - red if forced stop
        # - green if moving
        # - blue if idle
        moving = abs(self.cmd_v) > 0.01 or abs(self.cmd_w) > 0.01

        led = Marker()
        led.header.frame_id = 'base_link'
        led.header.stamp = now.to_msg()
        led.ns = 'led'
        led.id = 0
        led.type = Marker.CUBE
        led.action = Marker.ADD

        # Position on top of robot (matches your xacro-ish)
        led.pose.position.x = 0.0
        led.pose.position.y = 0.0
        led.pose.position.z = 0.09
        led.pose.orientation.w = 1.0

        led.scale.x = 0.20
        led.scale.y = 0.012
        led.scale.z = 0.010

        led.color.a = 0.85
        if too_close:
            led.color.r, led.color.g, led.color.b = 1.0, 0.0, 0.0
        elif moving:
            led.color.r, led.color.g, led.color.b = 0.0, 1.0, 0.0
        else:
            led.color.r, led.color.g, led.color.b = 0.0, 0.3, 1.0

        self.led_pub.publish(led)

        # ---- Buzzer ----
        buzzer_msg = Bool()
        buzzer_msg.data = bool(too_close)
        self.buzzer_pub.publish(buzzer_msg)

        if too_close:
            # Optional: system sound (works on many Ubuntu installs)
            # If it doesn't work on your VM, it's fine — marker + topic still shows "beep"
            try:
                subprocess.Popen(["bash", "-lc", "printf '\\a'"])
            except Exception:
                pass


def main():
    rclpy.init()
    node = EffectsDriver()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
