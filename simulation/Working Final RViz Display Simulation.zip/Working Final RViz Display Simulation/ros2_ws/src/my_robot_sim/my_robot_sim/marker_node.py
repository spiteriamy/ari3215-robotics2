import rclpy
from rclpy.node import Node
from visualization_msgs.msg import Marker
from std_msgs.msg import String, Int32

class MarkerNode(Node):
    def __init__(self):
        super().__init__('marker_node')
        self.pub = self.create_publisher(Marker, '/gesture_marker', 10)
        self.dir = "STOP"
        self.fingers = 0

        self.create_subscription(String, '/gesture/direction', self.on_dir, 10)
        self.create_subscription(Int32, '/gesture/value', self.on_val, 10)

        self.create_timer(0.1, self.tick)

    def on_dir(self, msg): self.dir = msg.data
    def on_val(self, msg): self.fingers = msg.data

    def tick(self):
        m = Marker()
        m.header.frame_id = "base_link"
        m.header.stamp = self.get_clock().now().to_msg()
        m.ns = "gesture"
        m.id = 0
        m.type = Marker.TEXT_VIEW_FACING
        m.action = Marker.ADD
        m.pose.position.z = 0.20
        m.scale.z = 0.08
        m.color.r = 1.0
        m.color.g = 1.0
        m.color.b = 1.0
        m.color.a = 1.0

        if self.dir in ("LEFT", "RIGHT"):
            m.text = f"{self.dir}  {30*self.fingers} deg"
        elif self.dir in ("FORWARD", "BACKWARD"):
            m.text = f"{self.dir}  {self.fingers} sec"
        else:
            m.text = self.dir

        self.pub.publish(m)

def main():
    rclpy.init()
    rclpy.spin(MarkerNode())
    rclpy.shutdown()
