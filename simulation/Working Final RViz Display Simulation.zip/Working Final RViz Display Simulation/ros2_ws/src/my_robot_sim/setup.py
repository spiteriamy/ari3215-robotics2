from setuptools import setup
from glob import glob
import os

package_name = 'my_robot_sim'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='clyde-vella',
    maintainer_email='clyde-vella@todo.todo',
    description='RViz-only simulation nodes (gesture control + fake sensors).',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'gesture_input = my_robot_sim.gesture_input_node:main',
            'pose_sim = my_robot_sim.pose_sim_node:main',
            'ultrasonic_sim = my_robot_sim.ultrasonic_sim_node:main',
            'imu_sim = my_robot_sim.imu_sim_node:main',
            'camera_sim = my_robot_sim.camera_sim_node:main',
            'marker_node = my_robot_sim.marker_node:main',
            'effects_driver = my_robot_sim.effects_driver:main',
        ],
    },
)
