from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import PathJoinSubstitution

def generate_launch_description():
    display = PathJoinSubstitution([
        FindPackageShare('my_robot_description'),
        'launch',
        'display.launch.py'
    ])

    return LaunchDescription([
        IncludeLaunchDescription(PythonLaunchDescriptionSource(display)),

        Node(package='my_robot_sim', executable='pose_sim', output='screen'),
        Node(package='my_robot_sim', executable='ultrasonic_sim', output='screen'),
        Node(package='my_robot_sim', executable='imu_sim', output='screen'),
        Node(package='my_robot_sim', executable='camera_sim', output='screen'),
        Node(package='my_robot_sim', executable='marker_node', output='screen'),
    ])
